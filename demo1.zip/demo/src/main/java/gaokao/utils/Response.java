package gaokao.utils;

import gaokao.entity.College;
import gaokao.entity.Major;

import javax.ejb.EJB;

public class Response {
    private boolean flag=false;
    @EJB
    private StudentInfo studentInfo;
    @EJB
    private CollegeInfo collegeInfo;
    @EJB
    private MajorInfo majorInfo;

    public Response(boolean flag, StudentInfo studentInfo, CollegeInfo collegeInfo, MajorInfo majorInfo) {
        this.flag = flag;
        this.studentInfo = studentInfo;
        this.collegeInfo = collegeInfo;
        this.majorInfo = majorInfo;
    }

    public boolean isFlag() {
        return flag;
    }

    public StudentInfo getStudentInfo() {
        return studentInfo;
    }

    public CollegeInfo getCollegeInfo() {
        return collegeInfo;
    }

    public MajorInfo getMajorInfo() {
        return majorInfo;
    }

    public Response() {
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public void setStudentInfo(StudentInfo studentInfo) {
        this.studentInfo = studentInfo;
    }

    public void setCollegeInfo(CollegeInfo collegeInfo) {
        this.collegeInfo = collegeInfo;
    }

    public void setMajorInfo(MajorInfo majorInfo) {
        this.majorInfo = majorInfo;
    }
}
