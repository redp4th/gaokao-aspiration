package gaokao.api;

import gaokao.utils.CollegeInfo;
import gaokao.utils.MajorInfo;
import gaokao.utils.Response;
import gaokao.wrapper.CollegeFacade;

import javax.ejb.EJB;
import java.util.List;

public class MajorImpl implements MajorSevice {
    @EJB
    private CollegeFacade collegeFacade;
    @Override
    public Response getMajorCapacity(String Uniname, String major) {
        CollegeInfo collegeInfo=collegeFacade.getCollegeInfo(Uniname);
        List<MajorInfo> majorList=collegeInfo.getMajorList();
        int size=majorList.size();
        MajorInfo majorinfo=null;
        for(int i=0;i<size;i++){
            majorinfo=majorList.get(i);
            if(majorinfo.getID().equals(major)) {
                break;
            }
        }
        Response response=new Response();
        response.setMajorInfo(majorinfo);
        return response;
    }
}
