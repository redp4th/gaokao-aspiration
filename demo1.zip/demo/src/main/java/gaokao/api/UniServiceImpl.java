package gaokao.api;

import gaokao.utils.CollegeInfo;
import gaokao.utils.Response;
import gaokao.wrapper.CollegeFacade;
import gaokao.wrapper.StudentFacade;

import javax.ejb.EJB;

public class UniServiceImpl implements UniService {
    @EJB
    private CollegeFacade collegeFacade;
    @Override
    public Response getUniInfo(String uniid) {
        CollegeInfo collegeInfo=collegeFacade.getCollegeInfo(uniid);
        Response response=new Response();
        response.setCollegeInfo(collegeInfo);
        return response;
    }
}
