package gaokao.api;

import gaokao.utils.Response;

import javax.ws.rs.*;

public interface UniService {

    @GET
    @Path("/getUniInfo")
    @Produces("application/json")
    Response getUniInfo(@QueryParam("Uniid") String uniid);
}
