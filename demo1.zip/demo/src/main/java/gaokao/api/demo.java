package gaokao.api;

import javax.ws.rs.ApplicationPath;

@ApplicationPath("/")
public class demo extends javax.ws.rs.core.Application{
}
