package gaokao.api;



import gaokao.utils.MajorInfo;
import gaokao.utils.Response;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import java.util.List;

@Path("/user")
public interface  UserSevice {
    //注册
    @GET
    @Path("/register")
    @Produces("application/json")
    Response registerApi(@QueryParam("id") String id,@QueryParam("username") String username, @QueryParam("password") String password, @QueryParam("Score") int Score);
    //登录
    @GET
    @Path("/login")
    @Produces("application/json")
    Response loginApi(@QueryParam("username") String username,@QueryParam("password") String password);

    //判断是填报
    @GET
    @Path("/isFilled")
    @Produces("application/json")
    Response isFilledApi(@QueryParam("id") String id);

    //填报志愿
    @GET
    @Path("/aspirations")
    @Produces("application/json")
    Response aspirations(@QueryParam("id") String id, @QueryParam("uniname") List<String> collegelsit , @QueryParam("majorinfo")List<String> majorinfolist);
}
