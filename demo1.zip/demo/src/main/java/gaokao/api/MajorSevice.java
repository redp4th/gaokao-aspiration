package gaokao.api;

import gaokao.utils.Response;       

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

public interface MajorSevice {
    @GET
    @Path("/getMajorCapacity")
    @Produces("application/json")
    Response getMajorCapacity(@QueryParam("Uniname") String Uniname, @QueryParam("Major") String major);
}
