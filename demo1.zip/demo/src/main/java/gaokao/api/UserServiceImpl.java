package gaokao.api;

import gaokao.entity.Student;
import gaokao.utils.Response;
import gaokao.utils.StudentInfo;
import gaokao.wrapper.StudentFacade;

import javax.ejb.EJB;
import java.util.*;

public class UserServiceImpl implements UserSevice {
    @EJB
    private  StudentFacade studentFacade;


    @Override
    public Response registerApi(String id,String username, String password, int Score) {
        //把studentinfo存入session
        Student student=new Student();
        student=studentFacade.register(id,password,Score,username);
        StudentInfo studentInfo=new StudentInfo();
        studentInfo=studentFacade.getInfo(student.getID());
        Response response=new Response();
        response.setFlag(true);
        return response;
    }

    @Override
    public Response loginApi(String username, String password) {
        //把studentinfo存入session
        boolean flag= studentFacade.login(username,password);
        StudentInfo studentinfo=new StudentInfo();
        if(flag){
            studentinfo=studentFacade.getInfo(username);
        }
        Response response=new Response();
        response.setFlag(flag);
        return response;
    }

    @Override
    public Response isFilledApi(String id) {
        StudentInfo studentinfo=studentFacade.getInfo(id);
        boolean flag=false;
        if (studentinfo.getAspirations()!=null){
            flag=true;
        }
        Response response=new Response();
        response.setFlag(flag);
        return response;
    }

    @Override
    //8 48
    public Response aspirations(String id, List<String> collegelsit, List<String> majorinfolist) {
        for(int i=0;i<8;i++){
            String[] majorinfo=new String[6];
            int k=0;
            for(int j=i;j<i+6;j++){
                majorinfo[k]=majorinfolist.get(j);
                k++;
            }
            studentFacade.editAspiration(id,collegelsit.get(i),majorinfo);
        }
        StudentInfo studentInfo=  studentFacade.getInfo(id);
        Response response=new Response();
        response.setStudentInfo(studentInfo);
        return response;
    }
}
