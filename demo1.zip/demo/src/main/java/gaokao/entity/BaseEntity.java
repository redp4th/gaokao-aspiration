package gaokao.entity;

public interface BaseEntity {
}
