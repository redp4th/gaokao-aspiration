package utils;

public class Response {
    String a=new String();

    public Response(String a) {
        this.a = a;
    }

    public Response() {
    }
}
