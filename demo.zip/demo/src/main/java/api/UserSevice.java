package api;

import utils.Response;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

@Path("/user")
public interface  UserSevice {
    //注册
    @GET
    @Path("/register")
    @Produces("application/json")
    Response registerApi(@QueryParam("username") String username, @QueryParam("password") String password, @QueryParam("Score") double Score);
}
